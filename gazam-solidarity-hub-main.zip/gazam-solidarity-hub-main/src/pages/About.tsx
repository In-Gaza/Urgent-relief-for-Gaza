import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { FixedDonationButton } from "@/components/FixedDonationButton";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { Card, CardContent } from "@/components/ui/card";
import { Heart, Users, Target, Globe } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";

const About = () => {
  const { t } = useLanguage();

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <WhatsAppButton />
      
      <main className="pt-20">
        <div className="py-20 px-4">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="text-center mb-16">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-hero bg-clip-text text-transparent">
                {t('about')}
              </h1>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto leading-relaxed">
                We are dedicated to providing humanitarian aid and support to the people of Gaza during these challenging times.
              </p>
            </div>

            {/* Mission Section */}
            <div className="grid md:grid-cols-2 gap-12 mb-16">
              <div className="space-y-6">
                <h2 className="text-3xl font-bold text-foreground">Our Mission</h2>
                <p className="text-muted-foreground leading-relaxed">
                  Our mission is to provide immediate humanitarian assistance to the people of Gaza who are facing unprecedented challenges. We work tirelessly to ensure that donations reach those who need them most, focusing on food security, medical aid, and emergency relief.
                </p>
                <p className="text-muted-foreground leading-relaxed">
                  Through transparency, accountability, and direct partnerships with local organizations, we strive to make a meaningful difference in the lives of families and children affected by the crisis.
                </p>
              </div>
              <div className="relative">
                <div className="absolute inset-0 bg-gradient-hero rounded-lg opacity-20"></div>
                <img 
                  src="/api/placeholder/500/400" 
                  alt="Our Mission" 
                  className="w-full h-80 object-cover rounded-lg shadow-card"
                />
              </div>
            </div>

            {/* Values Cards */}
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
              {[
                {
                  icon: Heart,
                  title: "Compassion",
                  description: "We act with empathy and understanding for those in need",
                  color: "bg-gradient-sunset",
                  shadow: "shadow-sunset"
                },
                {
                  icon: Users,
                  title: "Unity",
                  description: "Bringing people together for a common cause",
                  color: "bg-gradient-nature",
                  shadow: "shadow-nature"
                },
                {
                  icon: Target,
                  title: "Impact",
                  description: "Making every donation count with measurable results",
                  color: "bg-gradient-ocean",
                  shadow: "shadow-ocean"
                },
                {
                  icon: Globe,
                  title: "Global Reach",
                  description: "Connecting worldwide support with local needs",
                  color: "bg-gradient-warm",
                  shadow: "shadow-warm"
                }
              ].map((value, index) => {
                const Icon = value.icon;
                return (
                  <Card 
                    key={index}
                    className={`${value.shadow} hover:shadow-lg transition-all duration-300 transform hover:scale-105 animate-scale-in border-2 border-primary/10 hover:border-primary/30`}
                    style={{ animationDelay: `${index * 0.2}s` }}
                  >
                    <CardContent className="p-6 text-center">
                      <div className={`mx-auto w-16 h-16 ${value.color} rounded-full flex items-center justify-center mb-4`}>
                        <Icon className="h-8 w-8 text-white" />
                      </div>
                      <h3 className="text-lg font-bold mb-2">{value.title}</h3>
                      <p className="text-sm text-muted-foreground">
                        {value.description}
                      </p>
                    </CardContent>
                  </Card>
                );
              })}
            </div>

            {/* How We Help Section */}
            <div className="mb-16">
              <h2 className="text-3xl font-bold text-center mb-12">How We Help</h2>
              <div className="grid md:grid-cols-3 gap-8">
                {[
                  {
                    title: "Emergency Food Aid",
                    description: "Providing essential food packages to families facing hunger and malnutrition.",
                    image: "/api/placeholder/400/300"
                  },
                  {
                    title: "Medical Support",
                    description: "Supporting healthcare facilities with medical supplies and equipment.",
                    image: "/api/placeholder/400/300"
                  },
                  {
                    title: "Shelter & Safety",
                    description: "Helping displaced families find temporary shelter and safety.",
                    image: "/api/placeholder/400/300"
                  }
                ].map((item, index) => (
                  <Card 
                    key={index}
                    className="overflow-hidden shadow-card hover:shadow-glow transition-all duration-300 transform hover:scale-105 animate-fade-in-up"
                    style={{ animationDelay: `${index * 0.3}s` }}
                  >
                    <img 
                      src={item.image} 
                      alt={item.title}
                      className="w-full h-48 object-cover"
                    />
                    <CardContent className="p-6">
                      <h3 className="text-xl font-bold mb-3">{item.title}</h3>
                      <p className="text-muted-foreground">
                        {item.description}
                      </p>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>

            {/* Transparency Section */}
            <div className="bg-gradient-to-r from-primary/5 to-secondary/5 rounded-lg p-8 text-center">
              <h2 className="text-3xl font-bold mb-6">Transparency & Accountability</h2>
              <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-6">
                We believe in complete transparency. Every donation is tracked, and we provide regular reports on how funds are being used to help the people of Gaza.
              </p>
              <div className="grid md:grid-cols-3 gap-6 mt-8">
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">100%</div>
                  <div className="text-sm text-muted-foreground">Donation Transparency</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-secondary mb-2">24/7</div>
                  <div className="text-sm text-muted-foreground">Support Available</div>
                </div>
                <div className="text-center">
                  <div className="text-3xl font-bold text-primary mb-2">0%</div>
                  <div className="text-sm text-muted-foreground">Administrative Fees</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
      <FixedDonationButton />
    </div>
  );
};

export default About;