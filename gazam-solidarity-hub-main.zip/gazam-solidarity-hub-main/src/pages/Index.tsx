import { Navigation } from "@/components/Navigation";
import { HeroSection } from "@/components/HeroSection";
import { HungerCrisisSection } from "@/components/HungerCrisisSection";
import { NewsSection } from "@/components/NewsSection";
import { StoriesSection } from "@/components/StoriesSection";
import { Footer } from "@/components/Footer";
import { FixedDonationButton } from "@/components/FixedDonationButton";
import { WhatsAppButton } from "@/components/WhatsAppButton";

const Index = () => {
  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <WhatsAppButton />
      
      <main>
        <section id="home">
          <HeroSection />
        </section>
        
        <section id="hunger">
          <HungerCrisisSection />
        </section>
        
        <section id="news">
          <div className="py-20 px-4">
            <div className="max-w-6xl mx-auto">
              <NewsSection />
            </div>
          </div>
        </section>
        
        <section id="stories">
          <StoriesSection />
        </section>
      </main>
      
      <Footer />
      <FixedDonationButton />
    </div>
  );
};

export default Index;
