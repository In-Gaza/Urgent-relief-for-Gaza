import { useEffect, useState } from "react";
import { Navigation } from "@/components/Navigation";
import { Footer } from "@/components/Footer";
import { FixedDonationButton } from "@/components/FixedDonationButton";
import { WhatsAppButton } from "@/components/WhatsAppButton";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, Eye, Share2 } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import { supabase } from "@/integrations/supabase/client";

interface Article {
  id: string;
  title: string;
  content: string;
  summary: string;
  image_url: string;
  category: string;
  source: string;
  published_at: string;
}

const Articles = () => {
  const { t } = useLanguage();
  const [articles, setArticles] = useState<Article[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchArticles();
  }, []);

  const fetchArticles = async () => {
    try {
      const { data, error } = await supabase
        .from('articles')
        .select('*')
        .order('published_at', { ascending: false })
        .limit(12);

      if (error) throw error;
      setArticles(data || []);
    } catch (error) {
      console.error('Error fetching articles:', error);
      // Mock data as fallback
      setArticles([
        {
          id: '1',
          title: 'Gaza Children Face Severe Malnutrition Crisis',
          content: 'Detailed article about the hunger crisis...',
          summary: 'A comprehensive look at the devastating hunger crisis affecting children in Gaza.',
          image_url: '/api/placeholder/600/400',
          category: 'Health',
          source: 'Gaza Health Ministry',
          published_at: new Date().toISOString()
        },
        {
          id: '2',
          title: 'Medical Teams Struggle to Provide Care',
          content: 'Article about medical challenges...',
          summary: 'Healthcare workers face unprecedented challenges in providing medical care.',
          image_url: '/api/placeholder/600/400',
          category: 'Medical',
          source: 'International Medical Corps',
          published_at: new Date(Date.now() - 86400000).toISOString()
        }
      ]);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-primary"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navigation />
      <WhatsAppButton />
      
      <main className="pt-20">
        <div className="py-20 px-4">
          <div className="max-w-6xl mx-auto">
            {/* Header */}
            <div className="text-center mb-12">
              <h1 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-hero bg-clip-text text-transparent">
                {t('articles')}
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                In-depth articles and analysis about the situation in Gaza
              </p>
            </div>

            {/* Articles Grid */}
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {articles.map((article, index) => (
                <Card 
                  key={article.id}
                  className="overflow-hidden shadow-card hover:shadow-glow transition-all duration-300 transform hover:scale-105 animate-fade-in-up border-2 border-primary/10 hover:border-primary/30"
                  style={{ animationDelay: `${index * 0.2}s` }}
                >
                  <div className="relative">
                    <img 
                      src={article.image_url} 
                      alt={article.title}
                      className="w-full h-48 object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src = '/api/placeholder/600/400';
                      }}
                    />
                    <div className="absolute top-3 left-3">
                      <Badge className="bg-gradient-warm text-white">
                        {article.category}
                      </Badge>
                    </div>
                  </div>
                  
                  <CardHeader className="pb-3">
                    <CardTitle className="text-lg font-bold leading-tight line-clamp-2">
                      {article.title}
                    </CardTitle>
                  </CardHeader>
                  
                  <CardContent className="pt-0">
                    <p className="text-muted-foreground text-sm line-clamp-3 mb-4">
                      {article.summary}
                    </p>
                    
                    <div className="flex items-center justify-between text-xs text-muted-foreground mb-4">
                      <div className="flex items-center gap-2">
                        <Clock className="h-4 w-4" />
                        {new Date(article.published_at).toLocaleDateString()}
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="flex items-center gap-1">
                          <Eye className="h-4 w-4" />
                          {Math.floor(Math.random() * 1000) + 100}
                        </div>
                        <Share2 className="h-4 w-4 cursor-pointer hover:text-primary" />
                      </div>
                    </div>
                    
                    <div className="text-xs text-muted-foreground">
                      Source: {article.source}
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Load More Button */}
            <div className="text-center mt-12">
              <button className="px-8 py-3 bg-gradient-hero text-white rounded-lg hover:shadow-glow transition-all duration-300 transform hover:scale-105">
                Load More Articles
              </button>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
      <FixedDonationButton />
    </div>
  );
};

export default Articles;