import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

export type Language = 'en' | 'ar' | 'es' | 'pt' | 'fr' | 'tr';

interface Translations {
  [key: string]: {
    [K in Language]: string;
  };
}

const translations: Translations = {
  // Navigation
  home: {
    en: 'Home',
    ar: 'الرئيسية',
    es: 'Inicio',
    pt: 'Início',
    fr: 'Accueil',
    tr: 'Ana Sayfa'
  },
  news: {
    en: 'News',
    ar: 'الأخبار',
    es: 'Noticias',
    pt: 'Notícias',
    fr: 'Actualités',
    tr: 'Haberler'
  },
  stories: {
    en: 'Stories',
    ar: 'القصص',
    es: 'Historias',
    pt: 'Histórias',
    fr: 'Histoires',
    tr: 'Hikayeler'
  },
  articles: {
    en: 'Articles',
    ar: 'المقالات',
    es: 'Artículos',
    pt: 'Artigos',
    fr: 'Articles',
    tr: 'Makaleler'
  },
  about: {
    en: 'About Us',
    ar: 'من نحن',
    es: 'Nosotros',
    pt: 'Sobre Nós',
    fr: 'À Propos',
    tr: 'Hakkımızda'
  },
  contact: {
    en: 'Contact',
    ar: 'اتصل بنا',
    es: 'Contacto',
    pt: 'Contato',
    fr: 'Contact',
    tr: 'İletişim'
  },
  
  // Donation
  donateNow: {
    en: 'Donate Now',
    ar: 'تبرع الآن',
    es: 'Donar Ahora',
    pt: 'Doar Agora',
    fr: 'Faire un Don',
    tr: 'Şimdi Bağış Yap'
  },
  donateTitle: {
    en: 'Make a Donation',
    ar: 'قدم تبرعاً',
    es: 'Hacer una Donación',
    pt: 'Fazer uma Doação',
    fr: 'Faire un Don',
    tr: 'Bağış Yap'
  },
  
  // Hero Section
  heroTitle: {
    en: 'Gaza Needs You',
    ar: 'غزة تحتاجك',
    es: 'Gaza Te Necesita',
    pt: 'Gaza Precisa de Você',
    fr: 'Gaza a Besoin de Vous',
    tr: 'Gazze Sana İhtiyacı Var'
  },
  heroSubtitle: {
    en: 'Stand with the people of Palestine in their time of need',
    ar: 'قف مع شعب فلسطين في وقت محنتهم',
    es: 'Apoya al pueblo de Palestina en su momento de necesidad',
    pt: 'Apoie o povo da Palestina em seu momento de necessidade',
    fr: 'Soutenez le peuple palestinien dans son moment de besoin',
    tr: 'Filistin halkının ihtiyaç duyduğu bu zamanda yanında ol'
  },
  
  // Counters
  martyrs: {
    en: 'Martyrs',
    ar: 'شهيد',
    es: 'Mártires',
    pt: 'Mártires',
    fr: 'Martyrs',
    tr: 'Şehitler'
  },
  wounded: {
    en: 'Wounded',
    ar: 'جريح',
    es: 'Heridos',
    pt: 'Feridos',
    fr: 'Blessés',
    tr: 'Yaralılar'
  },
  donors: {
    en: 'Donors',
    ar: 'متبرع',
    es: 'Donantes',
    pt: 'Doadores',
    fr: 'Donateurs',
    tr: 'Bağışçılar'
  },
  totalDonations: {
    en: 'Total Raised',
    ar: 'دولار تم جمعه',
    es: 'Total Recaudado',
    pt: 'Total Arrecadado',
    fr: 'Total Collecté',
    tr: 'Toplanan Miktar'
  },
  live: {
    en: 'Live',
    ar: 'مباشر',
    es: 'En Vivo',
    pt: 'Ao Vivo',
    fr: 'En Direct',
    tr: 'Canlı'
  },
  
  // Hunger Crisis
  hungerCrisisTitle: {
    en: 'Gaza Hunger Crisis',
    ar: 'أزمة الجوع في غزة',
    es: 'Crisis de Hambre en Gaza',
    pt: 'Crise de Fome em Gaza',
    fr: 'Crise de la Faim à Gaza',
    tr: 'Gazze Açlık Krizi'
  }
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
  isRTL: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en');

  useEffect(() => {
    const savedLanguage = localStorage.getItem('language') as Language;
    if (savedLanguage && ['en', 'ar', 'es', 'pt', 'fr', 'tr'].includes(savedLanguage)) {
      setLanguage(savedLanguage);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem('language', language);
    document.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  const t = (key: string): string => {
    return translations[key]?.[language] || key;
  };

  const isRTL = language === 'ar';

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isRTL }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}