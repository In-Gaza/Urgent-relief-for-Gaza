import { Heart, Mail, Phone, MapPin, Facebook, Twitter, Instagram } from "lucide-react";
import { Button } from "@/components/ui/button";

export function Footer() {
  const socialLinks = [
    { icon: Facebook, href: "#", label: "Facebook" },
    { icon: Twitter, href: "#", label: "Twitter" },
    { icon: Instagram, href: "#", label: "Instagram" }
  ];

  const quickLinks = [
    "الصفحة الرئيسية",
    "آخر الأخبار",
    "القصص الإنسانية",
    "من نحن",
    "اتصل بنا",
    "سياسة الخصوصية"
  ];

  return (
    <footer className="bg-gradient-to-b from-palestine-black to-gray-900 text-white">
      <div className="max-w-6xl mx-auto px-4 py-16">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Logo and Mission */}
          <div className="lg:col-span-2">
            <div className="flex items-center gap-3 mb-6">
              <div className="w-12 h-12 bg-gradient-hero rounded-full flex items-center justify-center">
                <Heart className="h-8 w-8 text-white" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">غزة تستغيث</h2>
                <p className="text-gray-300">موقع التبرع الرسمي</p>
              </div>
            </div>
            <p className="text-gray-300 text-lg leading-relaxed mb-6">
              نحن منظمة إنسانية تهدف إلى تقديم المساعدة العاجلة لأهالي غزة. 
              كل تبرع يذهب مباشرة لمن يحتاجه في الوقت الذي يحتاجه فيه.
            </p>
            <div className="flex flex-wrap gap-4">
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <a
                    key={index}
                    href={social.href}
                    className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center hover:bg-primary transition-colors transform hover:scale-110"
                    aria-label={social.label}
                  >
                    <Icon className="h-5 w-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-xl font-bold mb-6">روابط سريعة</h3>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a 
                    href="#" 
                    className="text-gray-300 hover:text-white transition-colors hover:underline"
                  >
                    {link}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-xl font-bold mb-6">تواصل معنا</h3>
            <div className="space-y-4">
              <div className="flex items-center gap-3">
                <Mail className="h-5 w-5 text-primary" />
                <span className="text-gray-300">help@gaza-solidarity.org</span>
              </div>
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-primary" />
                <span className="text-gray-300" dir="ltr">+1 (555) 123-4567</span>
              </div>
              <div className="flex items-center gap-3">
                <MapPin className="h-5 w-5 text-primary" />
                <span className="text-gray-300">مكتب الإغاثة الدولية</span>
              </div>
            </div>

            <div className="mt-6">
              <Button variant="outline" className="w-full bg-white/10 border-white/20 text-white hover:bg-white/20">
                اتصل بنا
              </Button>
            </div>
          </div>
        </div>

        {/* Emergency Donation Section */}
        <div className="mt-12 p-8 bg-gradient-hero rounded-2xl text-center shadow-palestine">
          <h3 className="text-2xl font-bold mb-4">
            🚨 تبرع طوارئ - كل ثانية مهمة
          </h3>
          <p className="text-lg mb-6 opacity-90">
            الوضع يتطلب تدخلاً فورياً. ساعدنا في إنقاذ المزيد من الأرواح.
          </p>
          <Button variant="secondary" size="lg" className="bg-white text-primary hover:bg-gray-100 font-bold">
            <Heart className="mr-2 h-6 w-6" />
            تبرع الآن - حالة طوارئ
          </Button>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/20">
          <div className="flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-gray-400 text-center md:text-right">
              © 2024 غزة تستغيث. جميع الحقوق محفوظة.
            </p>
            <div className="flex items-center gap-4 text-sm text-gray-400">
              <span>🔒 دفع آمن ومشفر</span>
              <span>•</span>
              <span>✅ منظمة مرخصة</span>
              <span>•</span>
              <span>🌍 موثوقة دولياً</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}