import { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Clock, ExternalLink } from "lucide-react";
import hungerCrisisImg from "@/assets/hunger-crisis.jpg";
import medicalAidImg from "@/assets/medical-aid.jpg";
import aidDistributionImg from "@/assets/aid-distribution.jpg";

interface NewsItem {
  id: string;
  title: string;
  summary: string;
  image: string;
  category: string;
  timestamp: string;
  urgent: boolean;
}

export function NewsSection() {
  const [news, setNews] = useState<NewsItem[]>([]);

  // Simulate news fetching
  useEffect(() => {
    const mockNews: NewsItem[] = [
      {
        id: "1",
        title: "أزمة الجوع في غزة تتفاقم: أطفال يواجهون سوء التغذية الحاد",
        summary: "تقارير جديدة تكشف عن تفاقم أزمة الجوع في قطاع غزة، حيث يعاني آلاف الأطفال من سوء التغذية الحاد في ظل نقص المواد الغذائية الأساسية.",
        image: hungerCrisisImg,
        category: "إنساني",
        timestamp: "منذ ساعتين",
        urgent: true
      },
      {
        id: "2",
        title: "فرق طبية تقدم المساعدة للعائلات المحتاجة في غزة",
        summary: "فرق طبية محلية ودولية تواصل جهودها لتقديم الرعاية الصحية والمساعدات الطبية للعائلات المتضررة في قطاع غزة.",
        image: medicalAidImg,
        category: "صحة",
        timestamp: "منذ 4 ساعات",
        urgent: false
      },
      {
        id: "3",
        title: "توزيع مساعدات غذائية عاجلة على العائلات النازحة",
        summary: "استمرار عمليات توزيع المساعدات الغذائية والإغاثية على العائلات النازحة في مختلف مناطق قطاع غزة وسط ظروف إنسانية صعبة.",
        image: aidDistributionImg,
        category: "إغاثة",
        timestamp: "منذ 6 ساعات",
        urgent: true
      }
    ];

    setNews(mockNews);
  }, []);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl md:text-4xl font-bold mb-4 bg-gradient-hero bg-clip-text text-transparent">
          آخر الأخبار من غزة
        </h2>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          تابع آخر التطورات والأخبار المهمة من قطاع غزة
        </p>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {news.map((item, index) => (
          <Card 
            key={item.id} 
            className="overflow-hidden shadow-card-palestine hover:shadow-glow transition-all duration-300 transform hover:scale-105 animate-fade-in-up border-2 border-primary/10 hover:border-primary/30"
            style={{ animationDelay: `${index * 0.2}s` }}
          >
            <div className="relative">
              <img 
                src={item.image} 
                alt={item.title}
                className="w-full h-48 object-cover"
              />
              {item.urgent && (
                <Badge className="absolute top-3 right-3 bg-primary text-primary-foreground animate-pulse-glow">
                  عاجل
                </Badge>
              )}
              <div className="absolute bottom-0 left-0 right-0 bg-gradient-to-t from-black/60 to-transparent p-4">
                <Badge variant="secondary" className="text-xs">
                  {item.category}
                </Badge>
              </div>
            </div>
            
            <CardHeader className="pb-3">
              <CardTitle className="text-lg font-bold leading-tight line-clamp-2">
                {item.title}
              </CardTitle>
            </CardHeader>
            
            <CardContent className="pt-0">
              <p className="text-muted-foreground text-sm line-clamp-3 mb-4">
                {item.summary}
              </p>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-xs text-muted-foreground">
                  <Clock className="h-4 w-4" />
                  {item.timestamp}
                </div>
                <ExternalLink className="h-4 w-4 text-primary cursor-pointer hover:text-primary-hover" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}