import { Button } from "@/components/ui/button";
import { Heart, ArrowDown } from "lucide-react";
import { LiveCounters } from "./LiveCounters";
import heroImage from "@/assets/hero-gaza.jpg";

export function HeroSection() {
  const scrollToNews = () => {
    document.getElementById('news-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  const scrollToDonate = () => {
    document.getElementById('donation-section')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="relative min-h-screen">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-overlay"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Main Hero Content */}
        <div className="flex-1 flex items-center justify-center px-4 py-20">
          <div className="text-center text-white max-w-4xl mx-auto">
            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6 animate-fade-in-up">
              أنقذوا غزة
              <span className="block text-3xl md:text-5xl lg:text-6xl mt-2 text-yellow-300">
                🇵🇸 فلسطين تستغيث
              </span>
            </h1>
            
            <p className="text-xl md:text-2xl lg:text-3xl mb-8 animate-fade-in-up opacity-90" style={{ animationDelay: '0.2s' }}>
              كل تبرع ينقذ حياة.. كل دولار يصنع الفرق
            </p>
            
            <p className="text-lg md:text-xl mb-12 animate-fade-in-up opacity-80 max-w-2xl mx-auto" style={{ animationDelay: '0.4s' }}>
              انضم إلى آلاف المتبرعين حول العالم لمساعدة الأطفال والعائلات في غزة على البقاء والحصول على الطعام والدواء والمأوى
            </p>

            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center animate-fade-in-up" style={{ animationDelay: '0.6s' }}>
              <Button 
                variant="hero" 
                size="lg"
                onClick={scrollToDonate}
                className="min-w-[200px]"
              >
                <Heart className="mr-2 h-6 w-6" />
                تبرع الآن
              </Button>
              
              <Button 
                variant="outline" 
                size="lg"
                onClick={scrollToNews}
                className="min-w-[200px] bg-white/10 backdrop-blur-sm border-white/30 text-white hover:bg-white/20"
              >
                اقرأ القصص
                <ArrowDown className="ml-2 h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Live Counters */}
        <div className="px-4 pb-20">
          <div className="max-w-6xl mx-auto">
            <div className="text-center mb-8">
              <h2 className="text-2xl md:text-3xl font-bold text-white mb-2">
                إحصائيات مباشرة
              </h2>
              <p className="text-white/80">
                أرقام محدثة لحظياً من مصادر رسمية
              </p>
            </div>
            <LiveCounters />
          </div>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 animate-bounce">
          <ArrowDown className="h-8 w-8 text-white/60" />
        </div>
      </div>
    </div>
  );
}