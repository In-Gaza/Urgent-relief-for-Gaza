import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { AlertTriangle, Users, Baby, Utensils } from "lucide-react";
import hungerCrisisImg from "@/assets/hunger-crisis.jpg";

export function HungerCrisisSection() {
  const hungerStats = [
    {
      icon: Users,
      value: "2.2 مليون",
      label: "شخص يواجه انعدام الأمن الغذائي",
      color: "text-red-600"
    },
    {
      icon: Baby,
      value: "335,000",
      label: "طفل تحت سن الخامسة في خطر",
      color: "text-orange-600"
    },
    {
      icon: Utensils,
      value: "90%",
      label: "نقص في المواد الغذائية الأساسية",
      color: "text-red-700"
    }
  ];

  return (
    <section className="py-20 px-4 bg-gradient-to-b from-background to-muted/20">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="flex items-center justify-center gap-3 mb-6">
            <AlertTriangle className="h-12 w-12 text-red-600 animate-pulse" />
            <h2 className="text-4xl md:text-5xl font-bold text-red-600">
              أزمة الجوع في غزة
            </h2>
          </div>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            ملايين الأشخاص يواجهون الجوع الشديد في قطاع غزة. أطفال يموتون من سوء التغذية كل يوم.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Image and Stats */}
          <div className="space-y-8">
            <Card className="overflow-hidden shadow-card-palestine border-2 border-red-100">
              <img 
                src={hungerCrisisImg} 
                alt="أزمة الجوع في غزة"
                className="w-full h-64 object-cover"
              />
              <CardContent className="p-6">
                <h3 className="text-2xl font-bold mb-4 text-red-600">
                  الوضع الحالي للأمن الغذائي
                </h3>
                <div className="space-y-4">
                  {hungerStats.map((stat, index) => {
                    const Icon = stat.icon;
                    return (
                      <div key={index} className="flex items-center gap-4">
                        <div className="bg-red-50 p-3 rounded-full">
                          <Icon className={`h-6 w-6 ${stat.color}`} />
                        </div>
                        <div>
                          <div className={`text-2xl font-bold ${stat.color}`}>
                            {stat.value}
                          </div>
                          <p className="text-muted-foreground">{stat.label}</p>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Content */}
          <div className="space-y-8">
            <Card className="shadow-card-palestine border-2 border-primary/10">
              <CardHeader>
                <CardTitle className="text-2xl text-primary">
                  كيف يمكن لتبرعك أن يساعد؟
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-4">
                  <div className="border-r-4 border-primary pr-4">
                    <h4 className="font-bold text-lg mb-2">$50 دولار</h4>
                    <p className="text-muted-foreground">
                      توفر وجبات غذائية لعائلة من 5 أشخاص لمدة أسبوع كامل
                    </p>
                  </div>
                  
                  <div className="border-r-4 border-secondary pr-4">
                    <h4 className="font-bold text-lg mb-2">$100 دولار</h4>
                    <p className="text-muted-foreground">
                      تغذية 20 طفل بالحليب والأغذية المغذية لمدة شهر
                    </p>
                  </div>
                  
                  <div className="border-r-4 border-red-500 pr-4">
                    <h4 className="font-bold text-lg mb-2">$250 دولار</h4>
                    <p className="text-muted-foreground">
                      مساعدة طوارئ غذائية لـ 10 عائلات لمدة شهر كامل
                    </p>
                  </div>
                </div>

                {/* Progress toward goal */}
                <div className="bg-muted/30 p-6 rounded-lg">
                  <div className="flex justify-between items-center mb-4">
                    <span className="font-semibold">هدف الشهر الحالي</span>
                    <span className="text-2xl font-bold text-primary">
                      $500,000
                    </span>
                  </div>
                  <Progress value={68} className="mb-2" />
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>تم جمع: $340,000</span>
                    <span>68% مكتمل</span>
                  </div>
                </div>

                <Button 
                  variant="default" 
                  size="lg" 
                  className="w-full text-lg font-bold"
                >
                  <Utensils className="mr-2 h-6 w-6" />
                  أطعم عائلة اليوم
                </Button>
              </CardContent>
            </Card>

            {/* Urgent Appeal */}
            <Card className="bg-red-50 border-2 border-red-200 shadow-card-palestine">
              <CardContent className="p-6">
                <div className="flex items-center gap-3 mb-4">
                  <AlertTriangle className="h-8 w-8 text-red-600 animate-pulse" />
                  <h3 className="text-xl font-bold text-red-600">
                    نداء عاجل
                  </h3>
                </div>
                <p className="text-red-700 font-medium mb-4">
                  الوضع يتدهور يومياً. كل دقيقة تأخير تعني المزيد من المعاناة للأطفال والعائلات.
                </p>
                <Button variant="destructive" size="lg" className="w-full font-bold">
                  تبرع الآن - حالة طوارئ
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </section>
  );
}