import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Heart, CreditCard, Shield, Lock } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface DonationModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function DonationModal({ isOpen, onClose }: DonationModalProps) {
  const [amount, setAmount] = useState("");
  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [name, setName] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const { toast } = useToast();

  const handleDonate = async () => {
    if (!amount || !cardNumber || !expiryDate || !cvv || !name) {
      toast({
        title: "خطأ",
        description: "يرجى ملء جميع الحقول المطلوبة",
        variant: "destructive"
      });
      return;
    }

    setIsProcessing(true);
    
    // Simulate payment processing
    setTimeout(() => {
      toast({
        title: "شكراً لك! ✨",
        description: "تم استلام تبرعك بنجاح. ستصل رسالة تأكيد عبر البريد الإلكتروني",
      });
      setIsProcessing(false);
      onClose();
      // Reset form
      setAmount("");
      setCardNumber("");
      setExpiryDate("");
      setCvv("");
      setName("");
    }, 2000);
  };

  const quickAmounts = [50, 100, 250, 500, 1000];

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-gradient-to-br from-white to-muted/20 border-2 border-primary/20 shadow-palestine">
        <DialogHeader className="text-center">
          <DialogTitle className="text-3xl font-bold bg-gradient-hero bg-clip-text text-transparent">
            تبرع لغزة 🇵🇸
          </DialogTitle>
          <p className="text-muted-foreground text-lg">
            كل تبرع يصنع فرقاً في حياة العائلات المحتاجة
          </p>
        </DialogHeader>

        <div className="grid gap-6 mt-6">
          {/* Quick Amount Selection */}
          <Card className="shadow-card-palestine border-primary/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <Heart className="h-6 w-6 text-primary" />
                اختر مبلغ التبرع
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 md:grid-cols-5 gap-3 mb-4">
                {quickAmounts.map((quickAmount) => (
                  <Button
                    key={quickAmount}
                    variant={amount === quickAmount.toString() ? "default" : "outline"}
                    onClick={() => setAmount(quickAmount.toString())}
                    className="h-12 text-lg font-bold"
                  >
                    ${quickAmount}
                  </Button>
                ))}
              </div>
              <div className="space-y-2">
                <Label htmlFor="amount" className="text-lg font-semibold">
                  أو أدخل مبلغاً مخصصاً (بالدولار)
                </Label>
                <Input
                  id="amount"
                  type="number"
                  placeholder="0.00"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                  className="h-12 text-xl text-center font-bold border-2 border-primary/20 focus:border-primary"
                />
              </div>
            </CardContent>
          </Card>

          {/* Payment Information */}
          <Card className="shadow-card-palestine border-primary/10">
            <CardHeader>
              <CardTitle className="flex items-center gap-2 text-xl">
                <CreditCard className="h-6 w-6 text-primary" />
                معلومات الدفع
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <Label htmlFor="name" className="text-lg font-semibold">
                  الاسم الكامل
                </Label>
                <Input
                  id="name"
                  placeholder="أدخل اسمك كما هو مكتوب على البطاقة"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="h-12 border-2 border-primary/20 focus:border-primary"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="cardNumber" className="text-lg font-semibold">
                  رقم البطاقة
                </Label>
                <Input
                  id="cardNumber"
                  placeholder="1234 5678 9012 3456"
                  value={cardNumber}
                  onChange={(e) => setCardNumber(e.target.value)}
                  maxLength={19}
                  className="h-12 border-2 border-primary/20 focus:border-primary"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="expiryDate" className="text-lg font-semibold">
                    تاريخ الانتهاء
                  </Label>
                  <Input
                    id="expiryDate"
                    placeholder="MM/YY"
                    value={expiryDate}
                    onChange={(e) => setExpiryDate(e.target.value)}
                    maxLength={5}
                    className="h-12 border-2 border-primary/20 focus:border-primary"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="cvv" className="text-lg font-semibold">
                    الرقم السري (CVV)
                  </Label>
                  <Input
                    id="cvv"
                    placeholder="123"
                    value={cvv}
                    onChange={(e) => setCvv(e.target.value)}
                    maxLength={4}
                    type="password"
                    className="h-12 border-2 border-primary/20 focus:border-primary"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Security Notice */}
          <div className="flex items-center gap-3 p-4 bg-secondary/10 rounded-lg border border-secondary/20">
            <Shield className="h-8 w-8 text-secondary" />
            <div>
              <p className="font-semibold text-secondary">معاملة آمنة</p>
              <p className="text-sm text-muted-foreground">
                جميع معلوماتك محمية بتشفير SSL 256-bit
              </p>
            </div>
            <Lock className="h-6 w-6 text-secondary" />
          </div>

          {/* Donate Button */}
          <Button
            onClick={handleDonate}
            disabled={isProcessing}
            variant="donate"
            size="lg"
            className="h-16 text-xl font-bold"
          >
            {isProcessing ? (
              "جارِ المعالجة..."
            ) : (
              <>
                💖 تبرع الآن - ${amount || "0"}
              </>
            )}
          </Button>

          <p className="text-center text-sm text-muted-foreground">
            بالتبرع، أنت توافق على{" "}
            <span className="text-primary font-semibold cursor-pointer hover:underline">
              شروط الاستخدام
            </span>{" "}
            و{" "}
            <span className="text-primary font-semibold cursor-pointer hover:underline">
              سياسة الخصوصية
            </span>
          </p>
        </div>
      </DialogContent>
    </Dialog>
  );
}