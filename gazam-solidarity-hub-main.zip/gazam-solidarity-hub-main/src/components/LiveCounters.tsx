import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Users, Heart, HelpingHand, TrendingUp } from "lucide-react";
import { useLanguage } from "@/hooks/useLanguage";
import { supabase } from "@/integrations/supabase/client";

export function LiveCounters() {
  const { t } = useLanguage();
  const [counters, setCounters] = useState({
    martyrs: 45000,
    wounded: 85000,
    donors: 2547,
    totalDonations: 1250000
  });

  // Fetch real-time data from Supabase
  useEffect(() => {
    fetchCounters();
    
    // Simulate live updates and sync with database
    const interval = setInterval(() => {
      const newCounters = {
        martyrs: counters.martyrs + Math.floor(Math.random() * 3),
        wounded: counters.wounded + Math.floor(Math.random() * 5),
        donors: counters.donors + Math.floor(Math.random() * 10),
        totalDonations: counters.totalDonations + Math.floor(Math.random() * 1000)
      };
      
      setCounters(newCounters);
      updateCountersInDB(newCounters);
    }, 30000); // Update every 30 seconds

    return () => clearInterval(interval);
  }, []);

  const fetchCounters = async () => {
    try {
      const { data, error } = await supabase
        .from('news_counters')
        .select('*')
        .limit(1)
        .single();

      if (data) {
        setCounters({
          martyrs: data.martyrs_count,
          wounded: data.wounded_count,
          donors: data.donors_count,
          totalDonations: data.total_donations
        });
      }
    } catch (error) {
      console.error('Error fetching counters:', error);
    }
  };

  const updateCountersInDB = async (newCounters: any) => {
    try {
      await supabase
        .from('news_counters')
        .update({
          martyrs_count: newCounters.martyrs,
          wounded_count: newCounters.wounded,
          donors_count: newCounters.donors,
          total_donations: newCounters.totalDonations,
          last_updated: new Date().toISOString()
        })
        .eq('id', (await supabase.from('news_counters').select('id').limit(1).single()).data?.id);
    } catch (error) {
      console.error('Error updating counters:', error);
    }
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('ar-EG').format(num);
  };

  const counterData = [
    {
      icon: Users,
      count: counters.martyrs,
      label: t('martyrs'),
      color: "text-red-600",
      bgColor: "bg-red-50",
      iconColor: "text-red-600"
    },
    {
      icon: HelpingHand,
      count: counters.wounded,
      label: t('wounded'),
      color: "text-orange-600",
      bgColor: "bg-orange-50",
      iconColor: "text-orange-600"
    },
    {
      icon: Heart,
      count: counters.donors,
      label: t('donors'),
      color: "text-secondary",
      bgColor: "bg-secondary/10",
      iconColor: "text-secondary"
    },
    {
      icon: TrendingUp,
      count: counters.totalDonations,
      label: t('totalDonations'),
      color: "text-primary",
      bgColor: "bg-primary/10",
      iconColor: "text-primary",
      prefix: "$"
    }
  ];

  return (
    <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
      {counterData.map((item, index) => {
        const Icon = item.icon;
        return (
          <Card 
            key={index} 
            className={`${item.bgColor} border-2 border-opacity-20 shadow-card-palestine hover:shadow-glow transition-all duration-300 transform hover:scale-105 animate-scale-in`}
            style={{ animationDelay: `${index * 0.1}s` }}
          >
            <CardContent className="p-4 md:p-6 text-center">
              <div className={`mx-auto w-12 h-12 md:w-16 md:h-16 ${item.bgColor} rounded-full flex items-center justify-center mb-3`}>
                <Icon className={`h-6 w-6 md:h-8 md:w-8 ${item.iconColor}`} />
              </div>
              <div className={`text-2xl md:text-3xl lg:text-4xl font-bold ${item.color} mb-1`}>
                {item.prefix && <span className="text-lg md:text-xl">{item.prefix}</span>}
                {formatNumber(item.count)}
              </div>
              <p className="text-sm md:text-base font-semibold text-muted-foreground">
                {item.label}
              </p>
              <div className="mt-2 text-xs text-muted-foreground">
                <span className="inline-block w-2 h-2 bg-green-500 rounded-full animate-pulse mr-1"></span>
                {t('live')}
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}