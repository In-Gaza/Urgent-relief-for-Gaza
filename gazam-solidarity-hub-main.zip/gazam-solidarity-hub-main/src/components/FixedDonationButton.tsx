import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Heart } from "lucide-react";
import { DonationModal } from "./DonationModal";

export function FixedDonationButton() {
  const [isModalOpen, setIsModalOpen] = useState(false);

  return (
    <>
      {/* Fixed Donation Button */}
      <div className="fixed bottom-6 right-6 z-50">
        <Button
          variant="donate"
          size="lg"
          onClick={() => setIsModalOpen(true)}
          className="h-16 w-16 rounded-full shadow-2xl hover:shadow-glow border-4 border-white/30 animate-pulse-glow"
        >
          <Heart className="h-8 w-8" />
        </Button>
        
        {/* Floating text */}
        <div className="absolute -top-12 right-0 bg-primary text-primary-foreground px-3 py-1 rounded-lg text-sm font-bold shadow-lg animate-fade-in-up opacity-90">
          تبرع الآن
        </div>
      </div>

      <DonationModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
      />
    </>
  );
}