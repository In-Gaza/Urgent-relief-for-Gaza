import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Menu, X, Heart, Home, Newspaper, Users, Info, FileText, MessageCircle } from "lucide-react";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { useLanguage } from "@/hooks/useLanguage";

export function Navigation() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const { t } = useLanguage();

  const navItems = [
    { icon: Home, label: t('home'), href: "/", isExternal: false },
    { icon: Newspaper, label: t('news'), href: "#news", isExternal: false },
    { icon: FileText, label: t('articles'), href: "/articles", isExternal: false },
    { icon: Users, label: t('stories'), href: "#stories", isExternal: false },
    { icon: Info, label: t('about'), href: "/about", isExternal: false },
    { icon: MessageCircle, label: t('contact'), href: "/contact", isExternal: false }
  ];

  const handleNavigation = (href: string, isExternal: boolean) => {
    if (isExternal || href.startsWith('/')) {
      window.location.href = href;
    } else if (href.startsWith('#')) {
      const element = document.getElementById(href.replace('#', ''));
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
    setIsMenuOpen(false);
  };

  return (
    <nav className="fixed top-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md shadow-card-palestine border-b border-primary/10">
      <div className="max-w-6xl mx-auto px-4">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-hero rounded-full flex items-center justify-center shadow-palestine">
              <Heart className="h-6 w-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold bg-gradient-hero bg-clip-text text-transparent">
                غزة تستغيث
              </h1>
              <p className="text-xs text-muted-foreground">موقع التبرع الرسمي</p>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center gap-4">
            {navItems.map((item) => {
              const Icon = item.icon;
              return (
                <button
                  key={item.label}
                  onClick={() => handleNavigation(item.href, item.isExternal)}
                  className="flex items-center gap-2 px-3 py-2 rounded-lg text-foreground hover:bg-primary/10 hover:text-primary transition-all duration-200 transform hover:scale-105"
                >
                  <Icon className="h-4 w-4" />
                  {item.label}
                </button>
              );
            })}
            <LanguageSwitcher />
          </div>

          {/* Desktop Donate Button */}
          <div className="hidden md:block">
            <Button variant="donate" size="default">
              <Heart className="mr-2 h-4 w-4" />
              {t('donateNow')}
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMenuOpen(!isMenuOpen)}
            className="md:hidden p-2 rounded-lg hover:bg-primary/10 transition-colors"
          >
            {isMenuOpen ? (
              <X className="h-6 w-6 text-primary" />
            ) : (
              <Menu className="h-6 w-6 text-primary" />
            )}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden border-t border-primary/10 py-4 animate-fade-in-up">
            <div className="flex flex-col space-y-2">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <button
                    key={item.label}
                    onClick={() => handleNavigation(item.href, item.isExternal)}
                    className="flex items-center gap-3 px-4 py-3 rounded-lg text-foreground hover:bg-primary/10 hover:text-primary transition-all duration-200"
                  >
                    <Icon className="h-5 w-5" />
                    {item.label}
                  </button>
                );
              })}
              <div className="px-4 py-2">
                <LanguageSwitcher />
              </div>
              <div className="pt-2 border-t border-primary/10 mt-2">
                <Button variant="donate" size="default" className="w-full">
                  <Heart className="mr-2 h-4 w-4" />
                  {t('donateNow')}
                </Button>
              </div>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}