import { MessageCircle } from "lucide-react";
import { Button } from "@/components/ui/button";

export function WhatsAppButton() {
  const phoneNumber = "+201279102786";
  const message = "Hello, I want to know more about donations for Gaza";
  
  const handleWhatsAppClick = () => {
    const whatsappUrl = `https://wa.me/${phoneNumber.replace('+', '')}?text=${encodeURIComponent(message)}`;
    window.open(whatsappUrl, '_blank');
  };

  return (
    <Button
      onClick={handleWhatsAppClick}
      className="fixed left-4 bottom-20 z-50 w-14 h-14 rounded-full bg-gradient-nature shadow-nature hover:shadow-lg transform hover:scale-110 transition-all duration-300 animate-pulse-glow border-2 border-white/20 backdrop-blur-sm"
      size="icon"
    >
      <MessageCircle className="h-6 w-6 text-white" />
    </Button>
  );
}