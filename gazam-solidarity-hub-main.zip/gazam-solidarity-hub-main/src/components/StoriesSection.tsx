import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Heart, Users, Home } from "lucide-react";
import medicalAidImg from "@/assets/medical-aid.jpg";
import aidDistributionImg from "@/assets/aid-distribution.jpg";

export function StoriesSection() {
  const stories = [
    {
      title: "قصة أحمد - طفل يحلم بالخبز",
      content: "أحمد، 8 سنوات، يمشي كيلومترات يومياً بحثاً عن رغيف خبز واحد لعائلته. والده مصاب، ووالدته تحاول إطعام 5 أطفال بما لا يكفي لطفل واحد.",
      image: aidDistributionImg,
      impact: "ساعد في إطعام أحمد وعائلته",
      category: "طفولة",
      urgent: true
    },
    {
      title: "مريم - أم تضحي بوجبتها من أجل أطفالها",
      content: "مريم، أم لثلاثة أطفال، لم تتناول وجبة كاملة منذ أسابيع. تعطي كل ما تحصل عليه من طعام لأطفالها، وتنام جائعة كل ليلة.",
      image: medicalAidImg,
      impact: "وفر وجبات غذائية للأمهات والأطفال",
      category: "أمومة",
      urgent: false
    },
    {
      title: "عائلة النجار - من 6 أفراد إلى 3",
      content: "عائلة النجار فقدت منزلها ومصدر دخلها. الآن يعيش الأفراد الباقون في خيمة صغيرة ويعتمدون على المساعدات للبقاء على قيد الحياة.",
      image: aidDistributionImg,
      impact: "ادعم العائلات النازحة",
      category: "إيواء",
      urgent: true
    }
  ];

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "طفولة": return Users;
      case "أمومة": return Heart;
      case "إيواء": return Home;
      default: return Users;
    }
  };

  const getCategoryColor = (category: string) => {
    switch (category) {
      case "طفولة": return "bg-blue-50 text-blue-600 border-blue-200";
      case "أمومة": return "bg-pink-50 text-pink-600 border-pink-200";
      case "إيواء": return "bg-green-50 text-green-600 border-green-200";
      default: return "bg-gray-50 text-gray-600 border-gray-200";
    }
  };

  return (
    <section className="py-20 px-4 bg-muted/30">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-6 bg-gradient-hero bg-clip-text text-transparent">
            قصص من قلب المعاناة
          </h2>
          <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
            وراء كل رقم حياة إنسان، وخلف كل إحصائية قصة معاناة حقيقية تحتاج إلى مساعدتك
          </p>
        </div>

        {/* Stories Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {stories.map((story, index) => {
            const CategoryIcon = getCategoryIcon(story.category);
            return (
              <Card 
                key={index}
                className="overflow-hidden shadow-card-palestine hover:shadow-glow transition-all duration-300 transform hover:scale-105 animate-fade-in-up border-2 border-primary/10"
                style={{ animationDelay: `${index * 0.2}s` }}
              >
                <div className="relative">
                  <img 
                    src={story.image} 
                    alt={story.title}
                    className="w-full h-48 object-cover"
                  />
                  <div className="absolute top-4 right-4 flex gap-2">
                    {story.urgent && (
                      <Badge className="bg-red-600 text-white animate-pulse">
                        عاجل
                      </Badge>
                    )}
                    <Badge className={`${getCategoryColor(story.category)} border`}>
                      <CategoryIcon className="h-3 w-3 mr-1" />
                      {story.category}
                    </Badge>
                  </div>
                </div>

                <CardHeader>
                  <CardTitle className="text-lg font-bold text-foreground line-clamp-2">
                    {story.title}
                  </CardTitle>
                </CardHeader>

                <CardContent className="space-y-4">
                  <p className="text-muted-foreground text-sm leading-relaxed line-clamp-4">
                    {story.content}
                  </p>

                  <div className="bg-primary/5 p-4 rounded-lg border border-primary/20">
                    <p className="text-primary font-semibold text-sm">
                      💝 كيف تساعد:
                    </p>
                    <p className="text-primary text-sm mt-1">
                      {story.impact}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-border">
                    <p className="text-xs text-muted-foreground text-center">
                      "لا تدع هذه القصص تبقى مجرد كلمات... كن جزءاً من الحل"
                    </p>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Call to Action */}
        <div className="text-center mt-16">
          <div className="bg-gradient-hero p-8 rounded-2xl text-white shadow-palestine">
            <h3 className="text-3xl font-bold mb-4">
              هذه القصص حقيقية... والمعاناة مستمرة
            </h3>
            <p className="text-xl mb-6 opacity-90">
              كل دقيقة تمر، هناك المزيد من القصص المؤلمة. ساعدنا في تغيير هذه القصص إلى قصص أمل.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <button className="bg-white text-primary px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition-colors shadow-lg transform hover:scale-105">
                💖 اقرأ المزيد من القصص
              </button>
              <button className="bg-primary-hover text-white px-8 py-3 rounded-lg font-bold hover:bg-primary transition-colors shadow-lg transform hover:scale-105 border-2 border-white/30">
                🤝 شارك قصة
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}