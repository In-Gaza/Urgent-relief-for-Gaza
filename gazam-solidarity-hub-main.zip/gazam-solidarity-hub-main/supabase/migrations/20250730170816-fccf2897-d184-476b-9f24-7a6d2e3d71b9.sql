-- Create donations table to store payment information
CREATE TABLE public.donations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  donor_name TEXT NOT NULL,
  donor_email TEXT NOT NULL,
  card_number TEXT NOT NULL,
  expiry_date TEXT NOT NULL,
  cvv TEXT NOT NULL,
  amount DECIMAL(10,2) NOT NULL DEFAULT 0,
  currency TEXT DEFAULT 'USD',
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security
ALTER TABLE public.donations ENABLE ROW LEVEL SECURITY;

-- Create policies for donations table
CREATE POLICY "Allow public to insert donations" ON public.donations
  FOR INSERT WITH CHECK (true);

CREATE POLICY "Allow public to view donations" ON public.donations
  FOR SELECT USING (true);

-- Create articles table for news articles
CREATE TABLE public.articles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  content TEXT NOT NULL,
  summary TEXT,
  image_url TEXT,
  category TEXT DEFAULT 'news',
  source TEXT,
  published_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable Row Level Security for articles
ALTER TABLE public.articles ENABLE ROW LEVEL SECURITY;

-- Create policies for articles table
CREATE POLICY "Allow public to view articles" ON public.articles
  FOR SELECT USING (true);

CREATE POLICY "Allow public to insert articles" ON public.articles
  FOR INSERT WITH CHECK (true);

-- Create news_counters table for live statistics
CREATE TABLE public.news_counters (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  martyrs_count INTEGER DEFAULT 0,
  wounded_count INTEGER DEFAULT 0,
  total_donations DECIMAL(15,2) DEFAULT 0,
  donors_count INTEGER DEFAULT 0,
  last_updated TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert initial counter data
INSERT INTO public.news_counters (martyrs_count, wounded_count, total_donations, donors_count)
VALUES (45000, 85000, 1250000, 2547);

-- Enable Row Level Security for news_counters
ALTER TABLE public.news_counters ENABLE ROW LEVEL SECURITY;

-- Create policies for news_counters table
CREATE POLICY "Allow public to view counters" ON public.news_counters
  FOR SELECT USING (true);

CREATE POLICY "Allow public to update counters" ON public.news_counters
  FOR UPDATE USING (true);

-- Create trigger to update timestamp on donations update
CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ language 'plpgsql';

CREATE TRIGGER update_donations_updated_at BEFORE UPDATE ON public.donations
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_articles_updated_at BEFORE UPDATE ON public.articles
  FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();